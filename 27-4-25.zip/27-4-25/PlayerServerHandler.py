import ast
import socket
import threading
import json
import random
import signal
import sys
import time
from ServerMessageUtil import ServerMessageUtil
from battleship import Board, parse_coordinate, SHIPS
from Utility import Util

class PlayerServerHandler:
    client_detail = {}
    message_util = ServerMessageUtil()

    def handle(self, message):
        print("player server handler.handle message : ", message)

    def initiate_match(self, client_detail):
        self.board = Board()
        self.ships = SHIPS
        
        client_detail['client_socket'].send(str(Util.get_info_message("Match started! You are Player 1.\n")).encode())
        client_detail["client_socket"].send(str(self.message_util.get_place_ship_message(ships)).encode())
