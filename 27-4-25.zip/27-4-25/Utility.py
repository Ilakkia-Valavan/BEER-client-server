class Util:

    def __init__(self):
        print("")

    @staticmethod
    def print_info(message):
        print("\033[0;34m INFO: " + message + "\033[0m")
    
    @staticmethod
    def print_error(message):
        print("\033[1;31;40m ERROR: " + message + "\033[0m")

    @staticmethod
    def get_info_message(message):
        message = {"message_type": "INFO", "message" : message}
        return message

    @staticmethod
    def get_prompt_message(message):
        return "\033[0;32m INPUT: " + message + "\033[0m"


